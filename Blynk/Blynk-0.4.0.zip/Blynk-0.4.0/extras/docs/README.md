Please also take a look at [Blynk Firmware documentation](http://docs.blynk.cc/#blynk-firmware).
